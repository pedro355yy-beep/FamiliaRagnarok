// Config enviada por você
const firebaseConfig = {
  apiKey: "AIzaSyBR_UMg_Zn8hYmbhf3vmLhI7vN_0RSrVbQ",
  authDomain: "ragnarok-46684.firebaseapp.com",
  projectId: "ragnarok-46684",
  storageBucket: "ragnarok-46684.firebasestorage.app",
  messagingSenderId: "778435407612",
  appId: "1:778435407612:web:a5d8ed67eaa0984d3b3179",
  measurementId: "G-J9ZE6CKVG1"
};

// Inicia Firebase
const app = firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
const auth = firebase.auth();