// LOGIN
function login() {
  const email = document.getElementById("email").value;
  const senha = document.getElementById("password").value;

  auth.signInWithEmailAndPassword(email, senha)
    .then(() => {
      document.getElementById("login-area").style.display = "none";
      document.getElementById("painel").style.display = "block";
      carregarDepositos();
      carregarPresencas();
    })
    .catch(err => {
      document.getElementById("login-error").innerText = "Email ou senha errado";
    });
}

function logout() {
  auth.signOut();
  location.reload();
}

// REGISTRAR DEPÓSITO
function registrarDeposito() {
  const valor = Number(document.getElementById("depositoValor").value);
  const colete = Number(document.getElementById("depositoColete").value);

  db.collection("depositos").add({
    valor: valor,
    colete: colete,
    data: new Date()
  });
}

// LISTAR DEPÓSITOS
function carregarDepositos() {
  db.collection("depositos").onSnapshot(snapshot => {
    const lista = document.getElementById("lista-depositos");
    lista.innerHTML = "";
    snapshot.forEach(doc => {
      const d = doc.data();
      lista.innerHTML += `<li>💰 R$${d.valor} – 🦺 ${d.colete} coletes</li>`;
    });
  });
}

// PRESENÇA NA GUERRA
function registrarPresenca(foi) {
  db.collection("presencas").add({
    foi: foi,
    data: new Date()
  });
}

function carregarPresencas() {
  db.collection("presencas").onSnapshot(snap => {
    let presentes = 0;
    let faltas = 0;

    snap.forEach(doc => {
      if (doc.data().foi) presentes++;
      else faltas++;
    });

    document.getElementById("total-presenca").innerText = presentes;
    document.getElementById("total-faltas").innerText = faltas;
  });
}